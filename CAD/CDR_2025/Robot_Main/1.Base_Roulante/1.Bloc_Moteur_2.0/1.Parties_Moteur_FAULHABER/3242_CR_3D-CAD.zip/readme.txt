
Wichtige Hinweise zu den Nutzungsrechten
____________________________________

Die FAULHABER CAD 3D-Modelle sind eine kostenlose Service-Leistung der
Firma DR. FRITZ  FAULHABER GMBH & CO. KG, 71101 Sch�naich (Germany).
Sie d�rfen nur vollst�ndig und unver�ndert genutzt oder weitergegeben werden.
Jegliche Ver�nderungen sind unzul�ssig und versto�en gegen das Urheberrecht.

Alle Abmessungen sind in Millimeter angegeben. Dies muss insbesondere beim Laden
in CAD Systeme ber�cksichtigt werden, die auf anderen Einheiten basiert sind.
Es muss sichergestellt sein, dass die Abmessungen richtig �bernommen werden!
Vor dem Import in die CAD Anwendung Millimeter einstellen!

Diese Zeichnungen sind nur als Hilfsmittel zu verstehen. Sie sind jedoch - insbesondere
in Hinblick auf die Abmessungen und den Lieferumfang - nicht verbindlich und
unterliegen keinem automatischen �nderungsdienst.
Aktuelle Zeichnungen k�nnen �ber das Internet heruntergeladen werden unter:

http://www.faulhaber.com

Wir bem�hen uns um st�ndige Pflege und Verbesserung der Zeichnungen. Dennoch
k�nnen wir nicht garantieren, dass sie frei von Fehlern sind.
Die Nutzung der Daten erfolgt daher auf eigene Gefahr.

Durch die Benutzung der Daten erkl�ren Sie sich mit diesen Bestimmungen einverstanden.

(c) Copyright 2013, DR.FRITZ FAULHABER GMBH & CO.KG.
Alle Rechte vorbehalten.



Conditions of Use
____________________________________

The FAULHABER CAD 3D-Drawings are a free service of
DR. FRITZ  FAULHABER GMBH & CO. KG, 71101 Sch�naich (Germany).
They may only be used and distributed in a complete and unaltered form.
All copy rights reserved.

Please Note: All dimensions are displayed using the metric system (millimeters). 
Your CAD system maybe preset to another system of measurements or dimenstions.
Preset millimeter in the CAD application before importing the file!

These models are intended as a conceptual aid only. All dimensions are subject 
to change without notice. The most up-to-date drawings can be downloaded 
from the Internet at:

http://www.faulhaber.com

Though we encdeavor to maintain the accuracy of the models provided we can provide 
no guarantee of their accuracy.  Use of the models is at your own risk.

With the use of the data you agree with the aforementioned conditions.

(c) Copyright 2013, DR.FRITZ FAULHABER GMBH & CO.KG.
All rights reserved.
